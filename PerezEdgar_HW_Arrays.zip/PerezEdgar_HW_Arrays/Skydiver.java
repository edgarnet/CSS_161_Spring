/**
 * @author Edgar Perez
 * @version 1.7
 * The Skydiver class is responsible for the calculation of the change in velocity with respect to time.
 * The functions calculate v(t) and v(t-[delta]t) seperately, so as to organize the results,
 * as well as set/get functions for the values required to compute the entire formula.
 */
public class Skydiver {
	private double timeStep; //Instance variable for (delta)t (sec).
	private double drag; //Instance variable for the skydiver's drag coefficient.
	private double csArea; //Instance variable for the skydiver's cross-sectional area (m^2).
	private double mass; //Instance variable for the skydiver's mass (kg).
	
	public Skydiver(){ //Constructor with default values.
		setTimeStep(0);
		setDrag(0);
		setCSArea(0);
		setMass(0);
	}
	
	public Skydiver(double timeStep, double drag, double csArea, double mass){ //Constructor based on potential user input.
		setTimeStep(timeStep);
		setDrag(drag);
		setCSArea(csArea);
		setMass(mass);
	}
	
	public void setTimeStep(double value){ //Sets timeStep to the given value.
		timeStep = value;
	}
	
	public double getTimeStep(){ //Returns the current value of timeStep.
		return timeStep;
	}
	
	public void setDrag(double value){ //Sets drage to the given value.
		drag = value;
	}
	
	public double getDrag(){ //Returns the current value of drag.
		return drag;
	}
	
	public void setCSArea(double value){ //Sets csArea to the given value.
		csArea = value;
	}
	
	public double getCSArea(){ //Returns the current value of csArea.
		return csArea;
	}
	
	public void setMass(double value){ //Sets mass to the given value.
		mass = value;
	}
	
	public double getMass(){ //Returns the current value of mass.
		return mass;
	}
	
	public double velocity(double time){ //Returns the velocity at a given point in time.
		double aGravity = 9.81; //Gravitational acceleration (m/s^2).
		double velocity = aGravity*(time-getTimeStep()); //The value of the velocity.
		return velocity;
	}
	
	public double aCalc(double time){ //Returns the velocity for each change in time.
		double aGravity = 9.81;
		double airDense = 1.14; //Density of air (kg/m^3).
		double calc = (aGravity-((getDrag()*airDense*getCSArea())/(2*getMass()))
				*(velocity(time)*velocity(time)))*getTimeStep(); //The value of a possible velocity.
		return calc;
	}
}
