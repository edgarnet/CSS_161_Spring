import java.util.Scanner;
import java.io.PrintWriter;
import java.io.IOException;
/**
 * @author Edgar Perez
 * @version 1.7
 * This program collects user input to produce infinitesimal calculations of a skydiver's velocity,
 * which are then saved to a file of the user's choice (preferably .csv).
 * This is accomplished by initializing an object for Skydive which produces arrays that store data,
 * while initializing an object for Skydiver that produces each calculation.
 */
public class DiveDriver {
	public static void main(String args[]) throws IOException{ //Main method which runs the program.
		boolean complete = false; //Boolean for while loop menu.
		Scanner keyboard = new Scanner(System.in); //Scanner object for user input.

		while(!complete){
			System.out.println("\nEnter the mass of the skydiver (kg):");
			double mass = keyboard.nextDouble(); //Input for skydiver's mass.
			System.out.println("Enter the cross-sectional area of the skydiver (m^2):");
			double csArea = keyboard.nextDouble(); //Input for skydiver's C.S. Area.
			System.out.println("Enter the drag coefficient of the skydiver:");
			double drag = keyboard.nextDouble(); //Input for skydiver's drag coefficient.
			System.out.println("Enter the ending time (sec):");
			double endTime = keyboard.nextDouble(); //Input for the length of the dive.
			System.out.println("Enter the time step (sec):");
			double timeStep = keyboard.nextDouble(); //Input for (delta)t.
			System.out.println("Enter the output filename:");
			String file = keyboard.next(); //Input for the user's new filename.
			PrintWriter output = null; //PrintWriter object for output.

			try{
				output = new PrintWriter(file); //Checks for any errors associated with the user's file.
			}
			catch(IOException e){
				System.out.println("This file produced the following error: "+e.getMessage());
			}

			Skydive fly = new Skydive(timeStep, drag, csArea, mass, endTime); //Skydive object for data collection.
			double time[] = fly.timeSet(); //Dataset for change in time.
			double data[] = fly.dataSet(); //Dataset for change in velocity.
			for(int i = 0; i < time.length; i++){
				output.println(time[i]+", "+data[i]); //Prints the data from both sets separated by a comma.
			}
			System.out.println("Printing to file. Here are the first few lines:");
			fly.dataPreview(); //Prints the first few lines of the dataset.
			System.out.println("Enter another drive? (y/n):");
			String choice = keyboard.next(); //User input to continue with another drive.
			if(choice.equals("y")){
				complete = false;
			}
			else{
				output.close(); //Closes PrintWriter when complete.
				complete = true;
			}
		}
		//testStatistics();
	}

	public static void testStatistics(){ //Test method for statistical output.
		Skydive test = new Skydive(0.1, 0.581, 1.035, 80, 16);
		test.dataPreview();
	}
}
