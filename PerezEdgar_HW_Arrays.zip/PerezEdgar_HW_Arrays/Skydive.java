/**
 * @author Edgar Perez
 * @version 1.7
 * The Skydive class collects the calculations from initializing a Skydiver object.
 * The class then stores this data into two sepatate arrays, one for time and another for velocity.
 * The ability to 'preview' the stored data is also a method of the class.
 */
public class Skydive {
	private double endTime; //Instance variable for the length of the dive.
	Skydiver dive = new Skydiver(); //Initialized default Skydiver object.
	
	public Skydive(){ //Constructor with default values.
		System.out.println("No data to compute."); //Constructor with default values.
	}
	
	public Skydive(double timeStep, double drag, double csArea, double mass, double endTime){ //Constructor with expected values.
		dive = new Skydiver(timeStep, drag, csArea, mass); //Skydiver object with user input.
		setEndTime(endTime); //The dive's length is set.
	}
	
	public void setEndTime(double value){ //Sets endTime to the given 'value'.
		endTime = value;
	}
	
	public double getEndTime(){ //Retruns the current value of endTime.
		return endTime;
	}
	
	public int iteration(){ //Returns the amount of time changed in the value of endTime.
		int iterate = (int)(getEndTime()/dive.getTimeStep()); //Determines how many times the velocity is calculated.
		return iterate;
	}
	
	public double[] timeSet(){ //Returns an array for the change in time.
		double[] time = new double[iteration()]; //Initializes time array.
		double timeStep = dive.getTimeStep(); //Value for timeSteps.
		double vTime = timeStep; //Starting value of time = timeSteps.
		for(int i = 0; i < iteration(); i++){ 
			time[i] = vTime; //Change in time represented in each timeStep.
			vTime += timeStep; //As time steps, so does velocity.
		}
		return time;
	}
	
	public double[] dataSet(){ //Returns an array for the change in velocity.
		double[] data = new double[iteration()]; //Initializes data array.
		double timeStep = dive.getTimeStep();
		double vTime = timeStep;
		for(int i = 0; i < iteration(); i++){ 
			data[i] = dive.velocity(vTime)+dive.aCalc(vTime); //Change in velocity represented in each calculation.
			vTime += timeStep;
		}
		return data;
	}
	
	public void dataPreview(){ //Presents a preview for the data output.
		int preview = (int)(iteration()*0.1); //1/10 of all timeSteps are represented.
		double[] time = timeSet(); //Array for change in time.
		double[] data = dataSet(); //Array for change in velocity.
		for(int i = 0; i < preview; i++){
			System.out.printf("%.3f, %.4f%n",time[i],data[i]); //Output for the preview.
		}
	}
}
