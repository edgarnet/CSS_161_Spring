import java.util.Scanner;

/**
 * 
 * @author Edgar Perez
 * @version 1.4
 * 
 */
public class ReportDriver {
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in); //Scanner object for user input.
        boolean complete = false; //Boolean for while loop.
        while (!complete){
            System.out.println("Enter the race times (in seconds):");
            double firstRace = keyboard.nextDouble();  //Input for first racers.
            double secondRace = keyboard.nextDouble(); //Input for second racers.
            double thirdRace = keyboard.nextDouble();  //Input for third racers.
            Report data = new Report(firstRace, secondRace, thirdRace); //Creates Report object.
            System.out.println();   
            data.order(); //Outputs the order of the racers.
            System.out.println(); 
            data.overlap(); //Determines the overlap of the racers.
            data.rangeOutput(); //Determines the range of the racers.
            data.averageOutput(); //Determines the average of the racers.
            System.out.print("\n"
                    +"Enter another race? (y/n): ");
            String option = keyboard.next(); //Input for another race.
                if(option.equals("n")){ 
                    complete = true; //While becomes 'not true' if user enters 'n'.
                    keyboard.close();//Closes scanner object.
                }
            System.out.println();
        }
        //testStatistics();
    }
    
    public static void testStatistics(){ //Tests the classes for debug.
        Scanner input = new Scanner(System.in);
        double firstRace = input.nextDouble();  
        double secondRace = input.nextDouble(); 
        double thirdRace = input.nextDouble();
        Report test = new Report(firstRace, secondRace, thirdRace);
        test.order(); //Tests the order method.
        test.overlap(); //Tests the overlap method.
        test.rangeOutput(); //Tests the rangeOutput method.
        test.averageOutput(); //Tests the averageOutput method.
    }
}
