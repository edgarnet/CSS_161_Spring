import java.lang.Math;

public class Race {
	private double raceOne; //Instance variable for first race.
	private double raceTwo; //Instance variable for second race.
	private double raceThree; //Instance variable for third race.
	
	public Race(){ //Constructor for default values.
		raceOne = 0; 
		raceTwo = 0;
		raceThree = 0;
	}
	
	public Race(double one, double two, double three){ //Constructor for user input.
		if(one > 0){ //Sets value for each instance variables if input is positive.
			setRaceOne(one);
		}
		if(two > 0){
			setRaceTwo(two);
		}
		if(three > 0){
			setRaceThree(three);
		}
	}
	
	public void setRaceOne(double firstRace){ //Sets value for first racer.
		raceOne = firstRace;
	}
	
	public double getRaceOne(){ //Gets value for first racer.
		return raceOne;
	}
	
	public void setRaceTwo(double secondRace){ //Sets value for second racer.
		raceTwo = secondRace;
	}
	
	public double getRaceTwo(){ //Gets value for second racer.
		return raceTwo;
	}
	
	public void setRaceThree(double thirdRace){ //Sets value for third racer.
		raceThree = thirdRace;
	}
	
	public double getRaceThree(){ //Gets value for third racer.
		return raceThree;
	}
	
	public double slowestTime(){ //Returns the value of the slowest racer.
		double firstMax = Math.max(getRaceOne(), getRaceTwo()); //Slowest of first and second racer.
		double lastMax = Math.max(firstMax, getRaceThree()); //Slowest of firstMax and the third racer.
		return lastMax; //Returns the slowest racer.
	}
	
	public double fastestTime(){ //Returns the value of the fastest racer.
		double firstMin = Math.min(getRaceOne(), getRaceTwo()); //Fastest of first and second racer.
		double lastMin = Math.min(firstMin, getRaceThree()); //Fastest of firstMax and the third racer.
		return lastMin; //Returns the fastest racer.
	}
	
	public double medianTime(){ //Returns the second place racer.
		double total = getRaceOne() + getRaceTwo() + getRaceThree(); //Gets the total of the racers.
		double median = total - fastestTime() - slowestTime(); //Subtracts the total from imposible values.
		return median; //Returns the racer in the middle.
	}
	
	public double range(){ //Returns the range of the racers.
		double firstRange = slowestTime() - fastestTime(); //Subtracts the slowest value from the fastest.
		double lastRange = Math.abs(firstRange); //Takes the absolute value from the calculation above.
		return lastRange; //Returns the range of the racers.
	}
	
	public double average(){ //Returns the average.
		int numRace = 3; //Local variable for nubmer of racers.
		double sum = getRaceOne() + getRaceTwo() + getRaceThree(); //Adds all the racer's values.
		double average = sum/numRace; //Calculates the average.
		return average; //Returns the average of the racers.
	}
}
