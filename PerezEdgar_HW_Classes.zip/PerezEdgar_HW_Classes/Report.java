
public class Report {
	
	private Race score = new Race(); //Creates race object for user input.
	
	public Report(){ //Contructor for default values.
		System.out.println("There is no data for this report."); 
	}
	
	public Report(double firstRace, double secondRace, double thirdRace){ //Contructor for user input.
		score = new Race(firstRace, secondRace, thirdRace);
	}
	
	public void order(){ //Outputs the order of the racers' values.
		double firstPlace = score.fastestTime(); //Collects fastest time.
		System.out.printf("First place (time in seconds): %.1f\n",firstPlace); //Outputs fastest time.
		double secondPlace = score.medianTime(); //Collects median time.
		System.out.printf("Second place (time in seconds): %.1f\n",secondPlace); //Collects median time.
		double thirdPlace = score.slowestTime(); //Collects slowest time.
		System.out.printf("Third place (time in seconds): %.1f\n",thirdPlace); //Outputs slowest time.
	}
	
	public void overlap(){ //Outputs any overlap with the racer's values
		double firstPlace = score.fastestTime(); //Collects fastest time.
		double secondPlace = score.medianTime(); //Collects middle time.
		double thirdPlace = score.slowestTime(); //Collects slowest time.
		if(firstPlace == secondPlace && firstPlace == thirdPlace){ //If all are first place...
			System.out.println("All racers shared first place.");
		}
		else if(firstPlace == secondPlace && secondPlace != thirdPlace){ //If some are first place...
			System.out.println("Two racers shared first place.");
		}
		else if(firstPlace != secondPlace && secondPlace == thirdPlace){ //If some are second place...
			System.out.println("Two racers shared second place.");
		}
	}
	
	public void rangeOutput(){ //Outputs the range of the racers' values.
		double range = score.range(); //Collects range of time.
		System.out.printf("The range of the race times (in seconds): %.1f\n",range);
	}
	
	public void averageOutput(){ //Outputs the average of the racers' values.
		double average = score.average(); //Collects average of time.
		System.out.printf("The average time of all racers (in seconds): %.2f\n",average);
	}
		
}
